'''

Sophia Li and Brandon Demesa
Mr. Pittman
AP CSP Period 4
Data Visualization Project

'''

#Create multiple data visualizations to portray the correlation between crime and unemployment rates in the U.S.

import os.path
import matplotlib.pyplot as plt

directory = os.path.dirname(os.path.abspath(__file__))
# Build an absolute filename from directory + filename
filename = os.path.join(directory, 'chino_hills_unemployment_csv.csv')
datafile = open(filename,'r')
data = datafile.readlines()
lacrimefile = os.path.join(directory, 'los_angeles_crime.csv')
lacrimedatafile = open(lacrimefile, 'r')
lacrimedata = lacrimedatafile.readlines()

years = [] #year of recorded unemployment
years1 = [] #year of recorded crime
amount_unemployed = [] #actual count of unemployed residents
amount_crime = [] #amount of crime 

for line in data[7:12]: #iterates through data form 2012-2015
    
    #finds year and total unemployed residents and adds them to lists to be graphed
    Year, Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec, Total = line.split(',')     
    years.append(int(Year))
    amount_unemployed.append(int(Total))

for line in lacrimedata:
    Year, Crimes = line.split(',')
    years1.append(int(Year))
    amount_crime.append(int(Crimes))

#Plot line graph with x-axis year and y-axis amount of unemployed
fig, ax = plt.subplots(1,2)
ax[0].plot(years, amount_unemployed, '#cc0000')
ax[0].set_xlim(2012,2015)
ax[0].set_xlabel('Year')
ax[0].set_ylim(0,50000)
ax[0].set_ylabel('Unemployed Residents')
ax[0].set_axis_bgcolor('#446285')
ax[0].set_title('Amount of unemployed residents over 16 years of age \n in Chino Hills, CA from 2012-2015\n')
ax[1].plot(years1, amount_crime, '#e7bd42')
ax[1].set_xlim(2012,2015)
ax[1].set_xlabel('Year')
ax[1].set_ylim(0,550000)
ax[1].set_ylabel('Amount of Crimes')
ax[1].set_axis_bgcolor('#446285')
ax[1].set_title('Amount of documented crime \n in Chino Hills, CA from 2012-2015\n')
fig.patch.set_facecolor('white')
fig.show()


#repeat with Los Angeles, CA data
# Build an absolute filename from directory + filename
filename = os.path.join(directory, 'los_angeles_unemployment_csv.csv')
datafile = open(filename,'r')
data = datafile.readlines()
lacrimefile = os.path.join(directory, 'los_angeles_crime.csv')
lacrimedatafile = open(lacrimefile, 'r')
lacrimedata = lacrimedatafile.readlines()

years = [] #year of recorded unemployment
years1 = [] #year of recorded crime
amount_unemployed = [] #actual count of unemployed residents
amount_crime = []

for line in data[7:12]: #iterates through data form 2012-2015
    
    #finds year and total unemployed residents and adds them to lists to be graphed
    Year, Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec, Total = line.split(',')     
    years.append(int(Year))
    amount_unemployed.append(int(Total))

for line in lacrimedata:
    Year, Crimes = line.split(',')
    years1.append(int(Year))
    amount_crime.append(int(Crimes))

#Plot line graph with x-axis year and y-axis amount of unemployed
fig, ax = plt.subplots(1,2)
ax[0].plot(years, amount_unemployed, '#cc0000')
ax[0].set_xlim(2012,2015)
ax[0].set_xlabel('Year')
ax[0].set_ylim(0,3500000)
ax[0].set_ylabel('Unemployed Residents')
ax[0].set_axis_bgcolor('#446285')
ax[0].set_title('Amount of unemployed residents over 16 years of age \n in Los Angeles, CA from 2012-2015\n')
ax[1].plot(years1, amount_crime, '#e7bd42')
ax[1].set_xlim(2012,2015)
ax[1].set_xlabel('Year')
ax[1].set_ylim(0,550000)
ax[1].set_ylabel('Amount of Crimes')
ax[1].set_axis_bgcolor('#446285')
ax[1].set_title('Amount of documented crime \n in Los Angeles, CA from 2012-2015\n')
fig.patch.set_facecolor('white')
fig.show()


#repeat with New York, NY data
# Build an absolute filename from directory + filename
filename = os.path.join(directory, 'new_york_unemployment_csv.csv')
datafile = open(filename,'r')
data = datafile.readlines()
nycrimefile = os.path.join(directory, 'new_york_city_crime.csv')
nycrimedatafile = open(nycrimefile, 'r')
nycrimedata = nycrimedatafile.readlines()

years = [] #year of recorded unemployment
years1 = [] #year of recorded crime
amount_unemployed = [] #actual count of unemployed residents
amount_crime = []

for line in data[7:12]: #iterates through data form 2012-2015
    
    #finds year and total unemployed residents and adds them to lists to be graphed
    Year, Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec, Total = line.split(',')     
    years.append(int(Year))
    amount_unemployed.append(int(Total))

for line in nycrimedata:
    Year, Crimes = line.split(',')
    years1.append(int(Year))
    amount_crime.append(int(Crimes))

#Plot line graph with x-axis year and y-axis amount of unemployed
fig, ax = plt.subplots(1,2)
ax[0].plot(years, amount_unemployed, '#cc0000')
ax[0].set_xlim(2012,2015)
ax[0].set_xlabel('Year')
ax[0].set_ylim(0,4750000)
ax[0].set_ylabel('Unemployed Residents')
ax[0].set_axis_bgcolor('#446285')
ax[0].set_title('Amount of unemployed residents over 16 years of age \n in New York, NY from 2012-2015 \n')
ax[1].plot(years1, amount_crime, '#e7bd42')
ax[1].set_xlim(2012,2015)
ax[1].set_xlabel('Year')
ax[1].set_ylim(0,550000)
ax[1].set_ylabel('Amount of Crimes')
ax[1].set_axis_bgcolor('#446285')
ax[1].set_title('Amount of documented crime \n in New York, NY from 2012-2015\n')
fig.patch.set_facecolor('white')
fig.show()